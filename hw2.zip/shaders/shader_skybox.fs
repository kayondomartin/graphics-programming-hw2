#version 330 core
// TODO: define in/out and uniform variables.

void main()
{   
    // mix two texture

}
